package com.thabat.zadalkhair;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private long lastBackPressTime = 0L;

    private final ActivityResultLauncher<Intent> fileChooserLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (filePathCallback == null) return;
                Uri[] results = null;
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri dataUri = result.getData().getData();
                    if (dataUri != null) {
                        results = new Uri[]{dataUri};
                    }
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            });

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AlarmScheduler.createNotificationChannels(this);
        requestAppPermissions();

        webView = findViewById(R.id.webView);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setAllowFileAccessFromFileURLs(true);
        ws.setAllowUniversalAccessFromFileURLs(true);
        ws.setGeolocationEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("file://")) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                fileChooserLauncher.launch(Intent.createChooser(intent, "اختر ملف النسخة الاحتياطية"));
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/www/index.html");

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                webView.evaluateJavascript(
                        "(function(){ return window.__handleAndroidBack ? window.__handleAndroidBack() : 'exit'; })();",
                        value -> {
                            if (value != null && value.contains("handled")) {
                                return;
                            }
                            long now = System.currentTimeMillis();
                            if (now - lastBackPressTime < 2000) {
                                finish();
                            } else {
                                lastBackPressTime = now;
                                Toast.makeText(MainActivity.this, "اضغط مرة أخرى للخروج من التطبيق", Toast.LENGTH_SHORT).show();
                            }
                        }
                );
            }
        });
    }

    private void requestAppPermissions() {
        List<String> needed = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        if (!needed.isEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), 101);
        }
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void syncSchedule(String jsonConfig) {
            AlarmScheduler.saveAndSchedule(MainActivity.this, jsonConfig);
        }

        @JavascriptInterface
        public boolean exportBackupJson(String filename, String content) {
            try {
                byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                    values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri != null) {
                        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                            if (os != null) os.write(bytes);
                        }
                        runOnUiThread(() -> Toast.makeText(MainActivity.this, "تم حفظ النسخة في مجلد التنزيلات (Downloads)", Toast.LENGTH_LONG).show());
                        return true;
                    }
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists()) dir.mkdirs();
                    File outFile = new File(dir, filename);
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        fos.write(bytes);
                    }
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "تم حفظ النسخة في مجلد التنزيلات (Downloads)", Toast.LENGTH_LONG).show());
                    return true;
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "تعذر حفظ الملف", Toast.LENGTH_SHORT).show());
            }
            return false;
        }

        @JavascriptInterface
        public String getOfflineAudioPath(String key) {
            File f = new File(new File(getFilesDir(), "offline_audio"), key + ".mp3");
            if (f.exists() && f.length() > 1024) {
                return Uri.fromFile(f).toString();
            }
            return "";
        }

        @JavascriptInterface
        public String listBundledAssetAudioKeys() {
            JSONArray arr = new JSONArray();
            try {
                String[] list = getAssets().list("www/audio");
                if (list != null) {
                    for (String name : list) {
                        if (name.endsWith(".mp3")) {
                            arr.put(name.replace(".mp3", ""));
                        }
                    }
                }
            } catch (Exception ignored) {
            }
            return arr.toString();
        }

        @JavascriptInterface
        public String listOfflineAudioKeys() {
            JSONArray arr = new JSONArray();
            File dir = new File(getFilesDir(), "offline_audio");
            if (dir.exists() && dir.isDirectory()) {
                File[] files = dir.listFiles();
                if (files != null) {
                    for (File f : files) {
                        if (f.isFile() && f.getName().endsWith(".mp3") && f.length() > 1024) {
                            arr.put(f.getName().replace(".mp3", ""));
                        }
                    }
                }
            }
            return arr.toString();
        }

        @JavascriptInterface
        public void downloadAudioOffline(String key, String audioUrl) {
            new Thread(() -> {
                boolean ok = false;
                try {
                    File dir = new File(getFilesDir(), "offline_audio");
                    if (!dir.exists()) dir.mkdirs();
                    File tmp = new File(dir, key + ".tmp");
                    File dest = new File(dir, key + ".mp3");

                    HttpURLConnection conn = (HttpURLConnection) new URL(audioUrl).openConnection();
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(60000);
                    conn.connect();
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        try (InputStream is = conn.getInputStream();
                             FileOutputStream fos = new FileOutputStream(tmp)) {
                            byte[] buf = new byte[8192];
                            int len;
                            while ((len = is.read(buf)) != -1) {
                                fos.write(buf, 0, len);
                            }
                        }
                        if (tmp.length() > 1024) {
                            if (dest.exists()) dest.delete();
                            ok = tmp.renameTo(dest);
                        }
                    }
                    conn.disconnect();
                } catch (Exception ignored) {
                }
                final boolean finalOk = ok;
                runOnUiThread(() -> webView.evaluateJavascript(
                        "if(window.__onOfflineAudioReady){window.__onOfflineAudioReady('" + key + "'," + finalOk + ");}",
                        null
                ));
            }).start();
        }

        @JavascriptInterface
        public void downloadAndInstallUpdate(String apkUrl) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "جاري تنزيل التحديث الجديد...", Toast.LENGTH_SHORT).show());
            new Thread(() -> {
                try {
                    File updDir = new File(getCacheDir(), "updates");
                    if (!updDir.exists()) updDir.mkdirs();
                    File apkFile = new File(updDir, "Thabat-Update.apk");
                    if (apkFile.exists()) apkFile.delete();

                    HttpURLConnection conn = (HttpURLConnection) new URL(apkUrl).openConnection();
                    conn.setInstanceFollowRedirects(true);
                    conn.setConnectTimeout(20000);
                    conn.setReadTimeout(120000);
                    conn.connect();
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        try (InputStream is = conn.getInputStream();
                             FileOutputStream fos = new FileOutputStream(apkFile)) {
                            byte[] buf = new byte[16384];
                            int len;
                            while ((len = is.read(buf)) != -1) {
                                fos.write(buf, 0, len);
                            }
                        }
                        conn.disconnect();
                        if (apkFile.length() > 100000) {
                            runOnUiThread(() -> {
                                try {
                                    Uri apkUri = FileProvider.getUriForFile(
                                            MainActivity.this,
                                            getPackageName() + ".fileprovider",
                                            apkFile
                                    );
                                    Intent installIntent = new Intent(Intent.ACTION_VIEW);
                                    installIntent.setDataAndType(apkUri, "application/vnd.android.package-archive");
                                    installIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(installIntent);
                                } catch (Exception e) {
                                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(apkUrl)));
                                }
                            });
                            return;
                        }
                    }
                    conn.disconnect();
                } catch (Exception ignored) {
                }
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "سيتم فتح رابط التحديث في المتصفح...", Toast.LENGTH_SHORT).show();
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(apkUrl)));
                    } catch (Exception ignored) {}
                });
            }).start();
        }
    }
}
