package com.thabat.zadalkhair;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import org.json.JSONObject;

import java.util.Calendar;

public class AlarmScheduler {

    public static final String PREFS_NAME = "thabat_alarm_prefs";
    public static final String KEY_CONFIG_JSON = "schedule_config_json";

    public static final String CHANNEL_ADHAN = "thabat_adhan_channel";
    public static final String CHANNEL_SILENT = "thabat_silent_channel";
    public static final String CHANNEL_DHIKR = "thabat_dhikr_channel";

    private static final String[] PRAYER_KEYS = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
    private static final String[] PRAYER_NAMES_AR = {"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};
    private static final String[] PRAYER_HADITHS = {
            "قال ﷺ: «مَن صلَّى الصُّبحَ فَهوَ في ذمَّةِ اللَّهِ» — صحيح مسلم.",
            "قال ﷺ: «أربعٌ قبلَ الظُّهرِ ليسَ فيهنَّ تسليمٌ تُفتَحُ لهنَّ أبوابُ السَّماءِ» — سنن أبي داود.",
            "قال ﷺ: «مَن صَلَّى البَرْدَيْنِ دَخَلَ الجَنَّةَ» (الفجر والعصر) — متفق عليه.",
            "قال ﷺ: «لا تزالُ أمتي بخيرٍ ما لم يُؤخِّروا المغربَ إلى أن تشتبكَ النجومُ» — سنن أبي داود.",
            "قال ﷺ: «مَن صَلَّى العِشاءَ في جَماعَةٍ فَكَأنَّما قامَ نِصْفَ اللَّيْلِ» — صحيح مسلم."
    };

    public static void createNotificationChannels(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        // Adhan / Prayer alert channel with alarm sound
        NotificationChannel adhanCh = new NotificationChannel(
                CHANNEL_ADHAN,
                "تنبيهات أوقات الصلاة والأذان",
                NotificationManager.IMPORTANCE_HIGH
        );
        adhanCh.setDescription("إشعارات دخول وقت الصلاة وقبل الصلاة بـ 5 دقائق");
        adhanCh.enableVibration(true);
        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        adhanCh.setSound(alarmSound, attrs);
        nm.createNotificationChannel(adhanCh);

        // Silent prayer channel
        NotificationChannel silentCh = new NotificationChannel(
                CHANNEL_SILENT,
                "تنبيهات الصلاة (صامت)",
                NotificationManager.IMPORTANCE_DEFAULT
        );
        silentCh.setSound(null, null);
        silentCh.enableVibration(true);
        nm.createNotificationChannel(silentCh);

        // Periodic Dhikr channel
        NotificationChannel dhikrCh = new NotificationChannel(
                CHANNEL_DHIKR,
                "تذكير الأذكار الدوري",
                NotificationManager.IMPORTANCE_DEFAULT
        );
        dhikrCh.setDescription("تذكير بالصلاة على النبي ﷺ والاستغفار كل ساعة أو 3 ساعات");
        nm.createNotificationChannel(dhikrCh);
    }

    public static void saveAndSchedule(Context context, String configJson) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_CONFIG_JSON, configJson).apply();
        scheduleFromSavedConfig(context);
    }

    public static void scheduleFromSavedConfig(Context context) {
        createNotificationChannels(context);
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_CONFIG_JSON, null);
        if (raw == null || raw.isEmpty()) return;

        try {
            JSONObject cfg = new JSONObject(raw);
            JSONObject timings = cfg.optJSONObject("timings");
            String prayerSound = cfg.optString("prayerSound", "adhan");
            int dhikrHours = cfg.optInt("dhikrIntervalHours", 3);
            String dhikrPref = cfg.optString("dhikrPref", "mixed");
            boolean dhikrSound = cfg.optBoolean("dhikrSound", true);

            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;

            // Cancel existing alarms first
            cancelAll(context, am);

            // Schedule 5 prayers (both 5-min pre-alert with Hadith + exact time alert)
            if (timings != null && !"off".equals(prayerSound)) {
                for (int i = 0; i < PRAYER_KEYS.length; i++) {
                    String hhmm = timings.optString(PRAYER_KEYS[i], "");
                    if (!hhmm.contains(":")) continue;
                    String[] parts = hhmm.split(":");
                    int hour = Integer.parseInt(parts[0].trim());
                    int min = Integer.parseInt(parts[1].trim());

                    // 1) Exact prayer time
                    long exactMillis = nextOccurrenceMillis(hour, min);
                    Intent exactIntent = new Intent(context, NotificationReceiver.class);
                    exactIntent.putExtra("type", "prayer");
                    exactIntent.putExtra("title", "حان وقت صلاة " + PRAYER_NAMES_AR[i]);
                    exactIntent.putExtra("body", "حيّ على الصلاة — " + PRAYER_HADITHS[i]);
                    exactIntent.putExtra("channel", "adhan".equals(prayerSound) ? CHANNEL_ADHAN : CHANNEL_SILENT);
                    exactIntent.putExtra("notifId", 2000 + i);
                    scheduleSingle(context, am, 2000 + i, exactMillis, exactIntent);

                    // 2) 5 minutes before prayer
                    int preMin = min - 5;
                    int preHour = hour;
                    if (preMin < 0) {
                        preMin += 60;
                        preHour = (preHour + 23) % 24;
                    }
                    long preMillis = nextOccurrenceMillis(preHour, preMin);
                    Intent preIntent = new Intent(context, NotificationReceiver.class);
                    preIntent.putExtra("type", "pre_prayer");
                    preIntent.putExtra("title", "بقي 5 دقائق على صلاة " + PRAYER_NAMES_AR[i]);
                    preIntent.putExtra("body", PRAYER_HADITHS[i]);
                    preIntent.putExtra("channel", "adhan".equals(prayerSound) ? CHANNEL_ADHAN : CHANNEL_SILENT);
                    preIntent.putExtra("notifId", 3000 + i);
                    scheduleSingle(context, am, 3000 + i, preMillis, preIntent);
                }
            }

            // Schedule periodic Dhikr reminder
            if (dhikrHours > 0) {
                long intervalMs = dhikrHours * 3600L * 1000L;
                long triggerAt = System.currentTimeMillis() + intervalMs;
                Intent dhikrIntent = new Intent(context, NotificationReceiver.class);
                dhikrIntent.putExtra("type", "dhikr");
                dhikrIntent.putExtra("dhikrPref", dhikrPref);
                dhikrIntent.putExtra("dhikrIntervalHours", dhikrHours);
                dhikrIntent.putExtra("channel", dhikrSound ? CHANNEL_DHIKR : CHANNEL_SILENT);
                dhikrIntent.putExtra("notifId", 4001);
                scheduleSingle(context, am, 4001, triggerAt, dhikrIntent);
            }
        } catch (Exception ignored) {
        }
    }

    private static long nextOccurrenceMillis(int hour, int minute) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis() + 5000L) {
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }
        return cal.getTimeInMillis();
    }

    private static void scheduleSingle(Context context, AlarmManager am, int reqCode, long triggerMillis, Intent intent) {
        PendingIntent pi = PendingIntent.getBroadcast(
                context,
                reqCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi);
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi);
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, triggerMillis, pi);
            }
        } catch (SecurityException e) {
            am.set(AlarmManager.RTC_WAKEUP, triggerMillis, pi);
        }
    }

    private static void cancelAll(Context context, AlarmManager am) {
        int[] codes = {2000, 2001, 2002, 2003, 2004, 3000, 3001, 3002, 3003, 3004, 4001};
        for (int code : codes) {
            Intent i = new Intent(context, NotificationReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(
                    context, code, i, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
            );
            if (pi != null) {
                am.cancel(pi);
                pi.cancel();
            }
        }
    }
}
