package com.thabat.zadalkhair;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

import java.util.Random;

public class NotificationReceiver extends BroadcastReceiver {

    private static final String[][] DHIKR_POOL = {
            {"تذكير بالصلاة على النبي ﷺ", "اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَى سَيِّدِنَا مُحَمَّدٍ وَعَلَى آلِهِ وَصَحْبِهِ وَسَلِّمْ."},
            {"تذكير بالاستغفار", "أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ الَّذِي لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ."},
            {"تذكير بالذكر", "سُبْحَانَ اللَّهِ، وَالْحَمْدُ لِلَّهِ، وَلَا إِلَهَ إِلَّا اللَّهُ، وَاللَّهُ أَكْبَرُ."},
            {"كنز من كنوز الجنة", "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ."}
    };

    @Override
    public void onReceive(Context context, Intent intent) {
        AlarmScheduler.createNotificationChannels(context);

        String type = intent.getStringExtra("type");
        String channel = intent.getStringExtra("channel");
        if (channel == null) channel = AlarmScheduler.CHANNEL_DHIKR;
        int notifId = intent.getIntExtra("notifId", 1001);

        String title;
        String body;

        if ("dhikr".equals(type)) {
            String pref = intent.getStringExtra("dhikrPref");
            int idx;
            if ("salawat".equals(pref)) idx = 0;
            else if ("istighfar".equals(pref)) idx = 1;
            else idx = new Random().nextInt(DHIKR_POOL.length);
            title = DHIKR_POOL[idx][0];
            body = DHIKR_POOL[idx][1];
        } else {
            title = intent.getStringExtra("title");
            body = intent.getStringExtra("body");
            if (title == null) title = "ثبات | زاد الخير";
            if (body == null) body = "تذكير بوقت الطاعة والذكر";
        }

        Intent openIntent = new Intent(context, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentPi = PendingIntent.getActivity(
                context, notifId, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channel)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority("dhikr".equals(type) ? NotificationCompat.PRIORITY_DEFAULT : NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(contentPi);

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(notifId, builder.build());
        }

        // Reschedule next occurrence automatically
        AlarmScheduler.scheduleFromSavedConfig(context);
    }
}
