-keepclassmembers class com.thabat.zadalkhair.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
